<?php

namespace App\Services;

use Microsoft\Graph\Graph;
use Microsoft\Graph\Model;

class GraphMailer
{
    public static function send($to, $subject, $bodyHtml)
    {
        $accessToken = GraphTokenService::getAccessToken();

        if (!$accessToken) {
            throw new \Exception('فشل في الحصول على توكن Microsoft Graph');
        }

        $graph = new Graph();
        $graph->setAccessToken($accessToken);

        $email = [
            'message' => [
                'subject' => $subject,
                'body' => [
                    'contentType' => 'HTML',
                    'content' => $bodyHtml,
                ],
                'toRecipients' => [
                    [
                        'emailAddress' => [
                            'address' => $to,
                        ]
                    ]
                ],
            ],
            'saveToSentItems' => true
        ];

        return $graph->createRequest('POST', '/users/' . env('GRAPH_FROM') . '/sendMail')
            ->attachBody($email)
            ->execute();
    }
}
