<?php

namespace App\Services;

use GuzzleHttp\Client;

class GraphTokenService
{
    public static function getAccessToken(): ?string
    {
        $client = new Client();

        $response = $client->post('https://login.microsoftonline.com/' . env('MS_TENANT') . '/oauth2/v2.0/token', [
            'form_params' => [
                'client_id' => env('MS_CLIENT_ID'),
                'client_secret' => env('MS_CLIENT_SECRET'),
                'grant_type' => 'client_credentials',
                'scope' => 'https://graph.microsoft.com/.default',
            ],
        ]);

        $data = json_decode($response->getBody(), true);
        return $data['access_token'] ?? null;
    }
}
