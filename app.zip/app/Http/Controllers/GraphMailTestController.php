<?php

// app/Http/Controllers/GraphMailTestController.php
namespace App\Http\Controllers;

use App\Services\GraphMailService;

class GraphMailTestController extends Controller
{
    public function send(GraphMailService $graph)
    {
        $from = config('mail.from.address') ?? config('services.ms.account') ?? config('graph.from') ?? env('GRAPH_FROM');
        $to   = 'your-test@gmail.com';

        $graph->send(
            $from,
            $to,
            'اختبار إرسال عبر Microsoft Graph',
            '<p>تم الإرسال من Laravel عبر Graph ✅</p>',
            'تم الإرسال عبر Graph'
        );

        return 'تم — تحقق من البريد 👍';
    }
}
